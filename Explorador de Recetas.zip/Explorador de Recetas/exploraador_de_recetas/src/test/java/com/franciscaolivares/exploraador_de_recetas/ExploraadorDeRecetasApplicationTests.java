package com.franciscaolivares.exploraador_de_recetas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExploraadorDeRecetasApplicationTests {

	@Test
	void contextLoads() {
	}

}
