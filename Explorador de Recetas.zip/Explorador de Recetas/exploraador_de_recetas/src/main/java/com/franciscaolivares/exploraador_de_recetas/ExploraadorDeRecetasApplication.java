package com.franciscaolivares.exploraador_de_recetas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExploraadorDeRecetasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExploraadorDeRecetasApplication.class, args);
	}

}
