package com.franciscaolivares.peliculas_y_directores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculasYDirectoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
